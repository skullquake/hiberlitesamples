#ifndef INSERVISITOR_TMPL_HPP_INCLUDED
#define INSERVISITOR_TMPL_HPP_INCLUDED

namespace hiberlite{

} //namespace hiberlite


#endif // INSERVISITOR_TMPL_HPP_INCLUDED
