
#include "hiberlite.h"

namespace hiberlite{

//template<class C>
//std::map< bean_key, bean_ptr<C> > Registry<C>::beans=std::map< bean_key, bean_ptr<C> >();

} //namespace hiberlite
