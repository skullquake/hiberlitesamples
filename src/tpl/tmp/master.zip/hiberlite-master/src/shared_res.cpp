
#include "hiberlite.h"

namespace hiberlite{

bean_key::bean_key()
{
	id=Database::NULL_ID;
}

} //namespace hiberlite
